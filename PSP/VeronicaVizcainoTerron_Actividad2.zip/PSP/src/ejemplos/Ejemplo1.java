package ejemplos;

import java.io.IOException;

public class Ejemplo1 {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws IOException {
		
		ProcessBuilder pb = new ProcessBuilder("notepad.exe");
		
		Process p = pb.start();
		
//		  OTRA OPCI�N
//        Runtime runtime = Runtime.getRuntime(); 
//        Process process = runtime.exec("C:\\Windows\\System32\\notepad.exe C:\\Users\\venus\\Desktop\\Eclipse\\Ejercicios\\PSP\\src\\Actividad1\\file.txt");

 

	}

}
