package actividad1;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class LeerNombre2 {

	public static void main(String[] args) throws IOException {


//		// CREACI�N DE LISTA DE PROCESOS
//				List<String> list = new ArrayList<String>(); 
//		        list.add("java"); 
//		        list.add("LeerNombre"); 
				
				// CREAMOS OBJETO FILE AL DIRECTORIO DONDE ESTA EJEMPLO2
				File directorio = new File(".\\bin");
				
				Process p;
				
				// PROCESO A EJECUR ES EJEMPLO 2
				ProcessBuilder pb = new ProcessBuilder("java","actividad1.LeerNombre","Veronica");
				
				//SE ESTABLE EL DIRECTORIO DONDE SE ENCUENTRA EL EJECUTABLE
				pb.directory(directorio);
				
				System.out.printf("Directorio de trabajo: %s%n", pb.directory());
				
				// SE EJECUTA EL PROCESO
				p = pb.start();

				// OBTENER LA SALIDA DEVUELTA POR EL PROCESO
				try {
					InputStream is = p.getInputStream();
					int c;
					
					while((c = is.read()) != -1) {
						System.out.print((char) c);
						//is.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				// COMPROBACI�N DE ERROR { 0 BIEN, -1 MAL}
				int exitVal;
				
				try {
					exitVal = p.waitFor();
					System.out.println("Valor de salida: " + exitVal);    //RECOGE LA SALIDA DE SYSTEM.EXIT()
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				
	}

}

