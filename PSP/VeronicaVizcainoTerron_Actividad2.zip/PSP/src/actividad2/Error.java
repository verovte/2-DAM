package actividad2;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Error {

	public static void main(String[] args) throws IOException {
		
		// CREAMOS OBJETO FILE AL DIRECTORIO DONDE ESTA EJEMPLO2
				File directorio = new File(".\\bin");
				
				Process p;
				
				// PROCESO A EJECUR ES EJEMPLO 2
				ProcessBuilder pb = new ProcessBuilder("java","ejemplos.Ejemplo24");
				
				//SE ESTABLE EL DIRECTORIO DONDE SE ENCUENTRA EL EJECUTABLE
				pb.directory(directorio);
				
				System.out.printf("Directorio de trabajo: %s%n", pb.directory());
				
				// SE EJECUTA EL PROCESO
				p = pb.start();	
				
				// OBTENER LA SALIDA DEVUELTA POR EL PROCESO
				try {
					InputStream is = p.getInputStream();
					
					int c;
					
					while((c = is.read()) != -1) {
						System.out.print((char) c);
						//is.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				// COMPRUEBA SI HAY ERROR Y LO MUESTRA
				try {
					InputStream err = p.getErrorStream();
					BufferedReader br = new BufferedReader( new InputStreamReader(err));
					String liner = null;
					while((liner = br.readLine()) != null) {
						System.out.print("ERROR > " + liner);
						//is.close();
					}
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}

	}

}
