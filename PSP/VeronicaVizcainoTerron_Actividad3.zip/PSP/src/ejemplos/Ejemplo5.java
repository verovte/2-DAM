package ejemplos;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Ejemplo5 {

	public static void main(String[] args) throws IOException {

		File directorio = new File(".\\bin");
		
		ProcessBuilder pb = new ProcessBuilder("java","ejemplos.EjemploLectura");
		
		pb.directory(directorio);
		
		Process p = pb.start();

		// ESCRITURA --ENVIA ENTRADA
		OutputStream os = p.getOutputStream();

		os.write("Hola Ver\n".getBytes());

		// VACIA EL BUFFER DE SALIDA
		os.flush();

		// LECTURA -- OBTIENE LA SALIDA DE DATE
		// MOSTRAMOS CARACTER A CARACTER LA SALIDA GENERADA POR DIR
		try {
			InputStream is = p.getInputStream();
			int c;

			while ((c = is.read()) != -1) {
				System.out.print((char) c);
				//is.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// COMPROBACI�N DE ERROR { 0 BIEN, 1 MAL}
		int exitVal;

		try {
			exitVal = p.waitFor();
			System.out.println("Valor de salida: " + exitVal); // RECOGE LA SALIDA DE SYSTEM.EXIT()
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
