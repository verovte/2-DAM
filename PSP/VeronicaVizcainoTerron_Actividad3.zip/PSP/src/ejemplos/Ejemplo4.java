package ejemplos;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Ejemplo4 {

	public static void main(String[] args) throws IOException {
		
		// EJECUTAMOS EL PROCESO DATE
		Process p = new ProcessBuilder("CMD", "/C", "DATE").start();

		// ESCRITURA --ENVIA ENTRADA A DATE
		OutputStream os = p.getOutputStream();

		os.write("15-06-18".getBytes());

		// VACIA EL BUFFER DE SALIDA
		os.flush();

		// LECTURA -- OBTIENE LA SALIDA DE DATE
		// MOSTRAMOS CARACTER A CARACTER LA SALIDA GENERADA POR DIR
		try {
			InputStream is = p.getInputStream();
			int c;

			while ((c = is.read()) != -1) {
				System.out.print((char) c);
				// is.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// COMPROBACI�N DE ERROR { 0 BIEN, 1 MAL}
		int exitVal;

		try {
			exitVal = p.waitFor();
			System.out.println("Valor de salida: " + exitVal); // RECOGE LA SALIDA DE SYSTEM.EXIT()
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
