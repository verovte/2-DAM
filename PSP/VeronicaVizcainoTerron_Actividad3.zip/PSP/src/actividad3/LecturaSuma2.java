package actividad3;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class LecturaSuma2 {

	public static void main(String[] args) throws IOException {

		// CREAMOS OBJETO FILE AL DIRECTORIO DONDE ESTA EL EJERCICIO
		File direc = new File(".\\bin");

		Process p;

		// PROCESO A EJECUR ES EJEMPLO 2
		ProcessBuilder pb = new ProcessBuilder("java", "actividad3.LecturaSuma");

		// SE ESTABLE EL DIRECTORIO DONDE SE ENCUENTRA EL EJECUTABLE
		pb.directory(direc);

		System.out.printf("Directorio de trabajo: %s%n", pb.directory());

		// SE EJECUTA EL PROCESO
		p = pb.start();

		// ESCRITURA --ENVIA ENTRADA
		OutputStream os = p.getOutputStream();

		os.write("1\n".getBytes());
		os.write("2\n".getBytes());

		// VACIA EL BUFFER DE SALIDA
		os.flush();

		// OBTENER LA SALIDA DEVUELTA POR EL PROCESO
		try {
			InputStream is = p.getInputStream();

			int c;

			while ((c = is.read()) != -1) {
				System.out.print((char) c);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// COMPROBACI�N DE ERROR { 0 BIEN, 1 MAL}
		int exitVal;

		try {
			exitVal = p.waitFor();
			System.out.println("Valor de salida: " + exitVal); // RECOGE LA SALIDA DE SYSTEM.EXIT()
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
