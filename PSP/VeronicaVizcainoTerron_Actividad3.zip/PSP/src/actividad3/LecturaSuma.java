package actividad3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LecturaSuma {

	public static void main(String[] args) throws IOException {
		

		InputStreamReader in = new InputStreamReader(System.in);

		BufferedReader br = new BufferedReader(in);

		int num1, num2;
		boolean aux = true;

		do {
			try {
				System.out.print("Introduce 1� n�mero para la suma: ");
				num1 = Integer.parseInt(br.readLine());
				
				System.out.print("Introduce 2� n�mero para la suma: ");
				num2 = Integer.parseInt(br.readLine());
				System.out.println("");
				System.out.println("La suma de " + num1 + " y " + num2 + " es " + (num1+num2));
				aux = false;
				in.close();
			} catch (Exception e) {
				System.out.println("no se ha introducido numero");
				
			}
			
		}while(aux);
		
		

	}

}
