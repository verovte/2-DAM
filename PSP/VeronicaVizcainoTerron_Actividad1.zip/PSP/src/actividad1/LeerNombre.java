package actividad1;

import java.io.IOException;

public class LeerNombre {

	public static void main(String[] args) throws IOException, InterruptedException {

		// SI HAY M�S DE 1 PAR�METRO
		if (args.length > 1) {
			System.out.println("Hay demasiados par�metros. Debe escribir: LeerNombre nombrePersona");
			System.exit(-1);
		} else if (args.length == 0) {
			// SI NO HAY PAR�METROS
			System.out.println("Falta el nombre de la persona");
			System.exit(-1);
		} else {
			// SI HAY PAR�METRO
			System.out.println(args[0]);
			System.exit(1);
		}
		
		

	}

}
